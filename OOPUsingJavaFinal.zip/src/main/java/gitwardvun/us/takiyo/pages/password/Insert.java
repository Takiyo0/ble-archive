package gitwardvun.us.takiyo.pages.password;

import java.util.Arrays;
import java.util.Objects;

import gitwardvun.us.takiyo.Main;
import gitwardvun.us.takiyo.extensions.Page;
import gitwardvun.us.takiyo.handlers.Encryptor;

public class Insert extends Page {
	public Insert(Main main) {
		super(main, "password.insert");
	}

	@Override
	public String handlePage() {
		String type = main.getSpecificInput("Insert to what Company you want to insert your password into", new String[] {"Google", "Facebook", "Amazon"});
		System.out.print("Insert the password\n> ");
		String password = main.getStringInput();
		int score = 0;
		if (!Objects.equals(password.toLowerCase(), password)) score++;
		if (!Objects.equals(password.toUpperCase(), password)) score++;
		if (main.hasNumber(password)) score++;
		if (main.hasSpecialCharacter(password)) score++;
		if (password.length() > 8) score++;
		
		String strength = score == 1 ? "Weak" : score == 2 ? "Medium" : "Strong";
		System.out.println("Password strength: " + strength);
		main.waitForEnter();
		
		String targetPassword = Objects.equals(type, "Google") ? Encryptor.googleEncryption(password) : Objects.equals(type, "Facebook") ? Encryptor.facebookEncryption(password) : Encryptor.amazonEncrytion(password);
		main.addPassword(type, targetPassword, strength);
		return "home";
	}
}
