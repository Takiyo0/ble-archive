package gitwardvun.us.takiyo.pages;

import gitwardvun.us.takiyo.Main;
import gitwardvun.us.takiyo.extensions.Page;

public class Home extends Page {
	public Home(Main main) {
		super(main, "home");
	}

	@Override
	public String handlePage() {
		int targetChoice = main.sendChoices(new String[] {
				"Insert New Passwords",
				"View Passwords",
				"Update Passwords",
				"Delete Passwords",
				"Exit"
		});
		if (targetChoice == 5) {
			System.out.println("Bye bye!");
			System.exit(0);
		}
		
		return targetChoice == 1 ? "password.insert" : targetChoice == 2 ? "password.view" : targetChoice == 3 ? "password.update" : "password.delete";
	}
}