package gitwardvun.us.takiyo.pages.password;

import java.util.Objects;

import gitwardvun.us.takiyo.Main;
import gitwardvun.us.takiyo.extensions.Page;
import gitwardvun.us.takiyo.extensions.TakiyoList;
import gitwardvun.us.takiyo.handlers.Encryptor;
import gitwardvun.us.takiyo.interfaces.Password;

public class Delete extends Page{
	public Delete(Main main) {
		super(main, "password.delete");
	}

	@Override
	public String handlePage() {
		String choice = main.getSpecificInput("View passwords from which company", new String[] {"Google", "Facebook", "Amazon", "All"});
		TakiyoList<Password> passwords = main.getPasswords(choice);
		while (true) {
			System.out.printf("|%-10s|%-20s|%-20s|%-30s|\n", "No.", "Strength", "Password Type", "Hashed Password");
			int index = 0;
			for (Password password : passwords) {
				System.out.printf("|%-10s|%-20s|%-20s|%-30s|\n", ++index, password.getPasswordStrength(), password.getType(), password.getPassword());
			}
			System.out.print("'<' for previous page, '>' for next page, 'b' to go back to menu, input index you want to delete\n> ");
			String yes = main.getStringInput();
			if (yes.equals("b")) break;
			int num = main.tryParse(yes);
			if (num < 1 || num > passwords.size()) {
				main.sendError("Invalid index");
				continue;
			}
			passwords.remove(passwords.toArray()[index - 1]);
			System.out.println("Removed successfully");
			break;
		}
		return "home";
	}
}
