package gitwardvun.us.takiyo.pages.password;

import java.lang.classfile.attribute.StackMapFrameInfo.ObjectVerificationTypeInfo;
import java.util.Objects;

import gitwardvun.us.takiyo.Main;
import gitwardvun.us.takiyo.extensions.Page;
import gitwardvun.us.takiyo.extensions.TakiyoList;
import gitwardvun.us.takiyo.handlers.Encryptor;
import gitwardvun.us.takiyo.interfaces.Password;

public class Update extends Page {
	public Update(Main main) {
		super(main, "password.update");
	}

	@Override
	public String handlePage() {
		String choice = main.getSpecificInput("View passwords from which company", new String[] {"Google", "Facebook", "Amazon", "All"});
		TakiyoList<Password> passwords = main.getPasswords(choice);
		while (true) {
			System.out.printf("|%-10s|%-20s|%-20s|%-30s|\n", "No.", "Strength", "Password Type", "Hashed Password");
			int index = 0;
			for (Password password : passwords) {
				System.out.printf("|%-10s|%-20s|%-20s|%-30s|\n", ++index, password.getPasswordStrength(), password.getType(), password.getPassword());
			}
			System.out.print("'<' for previous page, '>' for next page, 'b' to go back to menu, input index you want to update\n> ");
			String yes = main.getStringInput();
			if (yes.equals("b")) break;
			int num = main.tryParse(yes);
			if (num < 1 || num > passwords.size()) {
				main.sendError("Invalid index");
				continue;
			}
			Password targetPassword = (Password) passwords.toArray()[index - 1];
			System.out.print("Insert the password\n> ");
			String password = main.getStringInput();
			int score = 0;
			if (!Objects.equals(password.toLowerCase(), password)) score++;
			if (!Objects.equals(password.toUpperCase(), password)) score++;
			if (main.hasNumber(password)) score++;
			if (main.hasSpecialCharacter(password)) score++;
			if (password.length() > 8) score++;
			
			String strength = score == 1 ? "Weak" : score == 2 ? "Medium" : "Strong";
			System.out.println("Password strength: " + strength);
			main.waitForEnter();
			
			String asdasd = Objects.equals(targetPassword.getType(), "Google") ? Encryptor.googleEncryption(password) : Objects.equals(targetPassword.getType(), "Facebook") ? Encryptor.facebookEncryption(password) : Encryptor.amazonEncrytion(password);
			System.out.println("Updated successfully");
			targetPassword.setPassword(asdasd);
			break;
		}
		return "home";
	}
}
