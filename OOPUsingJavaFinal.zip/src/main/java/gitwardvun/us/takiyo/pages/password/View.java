package gitwardvun.us.takiyo.pages.password;

import java.util.Objects;

import gitwardvun.us.takiyo.Main;
import gitwardvun.us.takiyo.extensions.Page;
import gitwardvun.us.takiyo.extensions.TakiyoList;
import gitwardvun.us.takiyo.interfaces.Password;

public class View extends Page{
	public View(Main main) {
		super(main, "password.view");
	}

	@Override
	public String handlePage() {
		String choice = main.getSpecificInput("View passwords from which company", new String[] {"Google", "Facebook", "Amazon", "All"});
		TakiyoList<Password> passwords = main.getPasswords(choice);
		while (true) {
			System.out.printf("|%-10s|%-20s|%-20s|%-30s|\n", "No.", "Strength", "Password Type", "Hashed Password");
			int index = 0;
			for (Password password : passwords) {
				System.out.printf("|%-10s|%-20s|%-20s|%-30s|\n", ++index, password.getPasswordStrength(), password.getType(), password.getPassword());
			}
			System.out.print("'<' for previous page, '>' for next page, 'f' to filter, 's' to show true passwords, 'b' to go back to menu\n> ");
			String c = main.getStringInput();
			if (c.equals("b")) break;
		}
		return "home";
	}
	
	
}
