package gitwardvun.us.takiyo.handlers;

public class Encryptor {
	public static String salt = "NAR25-1";
	public static String googleEncryption(String str) {
		char[] split = str.toCharArray();
		char[] result = new char[str.length()];
		
		for (int i = 0; i < split.length; i++) 
			result[i] = (char) ((int) split[i] + str.length());
		
		String fin = "";
		for (int i = 0; i < result.length; i++) 
			fin+= result[result.length - i - 1];
		
		return fin;
	};
	
	public static String facebookEncryption(String str) {
		char[] split = str.toCharArray();
		String result = "";
		
		for (int i = 0; i < split.length; i++) 
			result += (char) ((int) split[i] >> ((i % 5) + 1));
		
		return result;
	}
	
	public static String amazonEncrytion(String str) {
		char[] split = str.toCharArray();
		String result = "";
		
		for (int i = 0; i < split.length; i++) {
			if (i % 2 == 0) continue;
			Boolean nextExists = i+1 == split.length;
			result += swap(new char[] {split[i], nextExists ? split[i+1] : 'a'})[0];
			result += swap(new char[] {split[i], nextExists ? split[i+1] : 'a'})[1];
		}
		
		return result;
	}
	
	private static char[] swap(char[] original) {
		char[] yes = new char[original.length];
		for (int i = 0; i < original.length; i++) {
			yes[i] = original[original.length - 1 - i];
		}
		return yes;
	}
}
