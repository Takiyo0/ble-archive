package gitwardvun.us.takiyo.interfaces;

public class Password {
	private String type;
	private String password;
	private String passwordStrength;
	
	public Password(String type, String password, String strength) {
		this.setType(type);
		this.setPassword(password);
		this.setPasswordStrength(strength);
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPasswordStrength() {
		return passwordStrength;
	}

	public void setPasswordStrength(String passwordStrength) {
		this.passwordStrength = passwordStrength;
	}
}
