package gitwardvun.us.takiyo;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import gitwardvun.us.takiyo.extensions.Master;
import gitwardvun.us.takiyo.extensions.Page;
import gitwardvun.us.takiyo.extensions.TakiyoList;
import gitwardvun.us.takiyo.handlers.Encryptor;
import gitwardvun.us.takiyo.interfaces.Password;
import gitwardvun.us.takiyo.pages.Home;
import gitwardvun.us.takiyo.pages.password.Delete;
import gitwardvun.us.takiyo.pages.password.Insert;
import gitwardvun.us.takiyo.pages.password.Update;
import gitwardvun.us.takiyo.pages.password.View;

public class Main extends Master {
	private final TakiyoList<Page> pages = new TakiyoList<Page>();
//	private final Map<String, TakiyoList<String>> passwords = new HashMap<String, TakiyoList<String>>();
	private final TakiyoList<Password> passwords = new TakiyoList<Password>();
	
	public Main() {
		this.loadPages();
		this.handlePage();
	}
	public static void main(String[] args) {
		new Main();
//		System.out.printf("%s", Encryptor.amazonEncrytion("hallo world"));
	}
	
	public void addPassword(String type, String hashedPassword, String strength) {
//		if (passwords.get(type) == null) 
//			passwords.put(type, new TakiyoList<String>(hashedPassword));
//		else passwords.get(type).add(hashedPassword);
		System.out.println("Added " + type);
		passwords.add(new Password(type, hashedPassword, strength));
	}
	
	public TakiyoList<Password> getPasswords(String type) {
		TakiyoList<Password> finalList = new TakiyoList<Password>();
		if (Objects.equals(type, "All")) return passwords;
		
		for (Password d : passwords) 
				if(Objects.equals(d.getType(), type)) finalList.add(d);
		return finalList;
	}
	
	private void handlePage() {
		String currentPage = pages.get(0).getPageId();
		
		while (true) {
			Page curPage = pages.get(Page::getPageId, currentPage);
			if (curPage == null) {
				System.out.println("No page available");
				System.exit(0);
			}
			currentPage = curPage.handlePage();
		}
	}
	
	private void loadPages() {
		Page[] pages = {new Home(this), new Insert(this), new View(this), new Update(this), new Delete(this)};
		this.pages.addAll(Arrays.asList(pages));
	}
}
