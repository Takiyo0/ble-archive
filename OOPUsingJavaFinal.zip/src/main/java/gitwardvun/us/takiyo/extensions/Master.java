package gitwardvun.us.takiyo.extensions;

import java.util.Arrays;
import java.util.Scanner;

public class Master {
	public static Scanner scanner = new Scanner(System.in);

	public void clearTerminal() {
		for (int i = 0; i < 50; i++)
			System.out.print("\r\n");
	}

	public int getChoice() {
		try {
			return Integer.parseInt(scanner.nextLine());
		} catch (Exception e) {
			return -1;
		}
	}

	public int sendChoices(String[] choices) {
		while (true) {
			clearTerminal();
			for (int i = 0; i < choices.length; i++) {
				System.out.printf("%d. %s\n", i + 1, choices[i]);
			}
			System.out.print("> ");
			int choice = getChoice();
			if (choice < 1 || choice > choices.length) {
				sendError("Invalid choice");
				continue;
			}
			return choice;
		}
	}

	public String getSpecificInput(String message, String[] options) {
		while (true) {
			clearTerminal();
			System.out.print(message + " [");
			for (int i = 0; i < options.length; i++) {
				System.out.printf("%s%s", options[i], i == options.length - 1 ? "" : ", ");
			}
			System.out.printf("]\n>");
			String choice = scanner.nextLine();
			if (!Arrays.asList(options).contains(choice)) {
				sendError("Invalid option.");
				continue;
			}
			return choice;
		}
	}

	public boolean hasNumber(String y) {
		boolean has = false;
		for (int i = 0; i < y.length(); i++) {
			if (tryParse(y.split("")[i]) != -1)
				has = true;
		}
		return has;
	}

	public boolean hasSpecialCharacter(String y) {
		// TODO : Implement this
		return true;
	}

	public String getStringInput() {
		while (true) {
			String dString = scanner.nextLine();
			if (dString.isEmpty() || dString.isBlank()) {
				sendError("Input must not be empty");
				continue;
			}
			return dString;
		}
	}

	public int tryParse(String str) {
		try {
			return Integer.parseInt(str);
		} catch (Exception e) {
			return -1;
		}
	}

	public void sendError(String message) {
		System.out.println(message);
		waitForEnter();
	}

	public void waitForEnter() {
		try {
			System.out.print("Press ENTER to continue...");
			scanner.nextLine();
		} catch (Exception e) {
		}
	}
}
