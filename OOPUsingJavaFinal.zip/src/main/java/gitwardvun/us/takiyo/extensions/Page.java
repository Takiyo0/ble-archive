package gitwardvun.us.takiyo.extensions;

import gitwardvun.us.takiyo.Main;

public abstract class Page {
	public final Main main;
	private final String pageId;
	public Page(Main main, String pageId) {
		this.main = main;
		this.pageId = pageId;
	}
	
	public abstract String handlePage();

	public String getPageId() {
		return pageId;
	}
}
