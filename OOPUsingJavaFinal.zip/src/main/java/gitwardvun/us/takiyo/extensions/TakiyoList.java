package gitwardvun.us.takiyo.extensions;

import java.util.ArrayList;
import java.util.Objects;
import java.util.function.Function;

public class TakiyoList<V> extends ArrayList<V> {
	/**
	 * hallo
	 */
	private static final long serialVersionUID = -7272804572865901864L;

	public TakiyoList() {
		super();
	}
	
	public TakiyoList(V initialValue) {
		super();
		this.add(initialValue);
	}
	
	public V get(Function<V, String> fun, String value) {
		for (V d : this) {
			if(Objects.equals(fun.apply(d), value)) return d;
		}
		return null;
	}
}
