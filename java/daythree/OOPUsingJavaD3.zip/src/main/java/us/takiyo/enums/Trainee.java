package us.takiyo.enums;

public class Trainee {
    public enum Gender {
        Male,
        Female
    }
}
