package us.takiyo.resources;

import us.takiyo.extensions.ResourceExtension;

public class Stone extends ResourceExtension {
    public Stone() {
        super("stone", 40);
    }
}
