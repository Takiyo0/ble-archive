package us.takiyo.resources;

import us.takiyo.extensions.ResourceExtension;

public class Wood extends ResourceExtension {
    public Wood() {
        super("wood", 40);
    }
}
