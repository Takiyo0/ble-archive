package us.takiyo.resources;

import us.takiyo.extensions.ResourceExtension;

public class Money extends ResourceExtension {
    public Money() {
        super("money", 0);
    }
}