package us.takiyo.resources;

import us.takiyo.extensions.ResourceExtension;

public class Gold extends ResourceExtension {
    public Gold() {
        super("gold", 40);
    }
}
