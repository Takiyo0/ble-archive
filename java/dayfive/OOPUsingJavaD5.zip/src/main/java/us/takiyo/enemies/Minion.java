package us.takiyo.enemies;

import us.takiyo.controller.Enemy;

public class Minion extends Enemy {
    public Minion() {
        super("minion", 50, 10, 5, 15, 60,null);
    }
}
