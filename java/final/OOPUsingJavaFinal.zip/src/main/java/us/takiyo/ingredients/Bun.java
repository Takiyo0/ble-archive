package us.takiyo.ingredients;

import us.takiyo.extensions.Ingredient;

public class Bun extends Ingredient{
	public Bun() {
		super("bun");
	}
}
