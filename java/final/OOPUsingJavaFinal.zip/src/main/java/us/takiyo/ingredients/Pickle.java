package us.takiyo.ingredients;

import us.takiyo.extensions.Ingredient;

public class Pickle extends Ingredient{
	public Pickle() {
		super("pickle");
	}
}
