package us.takiyo.ingredients;

import us.takiyo.extensions.Ingredient;

public class Tomato extends Ingredient {
	public Tomato() {
		super("tomato");
	}
}
