package us.takiyo.ingredients;

import us.takiyo.extensions.Ingredient;

public class Bacon extends Ingredient{
	public Bacon() {
		super("bacon");
	}
}
