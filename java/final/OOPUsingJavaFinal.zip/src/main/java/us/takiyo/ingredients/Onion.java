package us.takiyo.ingredients;

import us.takiyo.extensions.Ingredient;

public class Onion extends Ingredient {
	public Onion() {
		super("onion");
	}
}
