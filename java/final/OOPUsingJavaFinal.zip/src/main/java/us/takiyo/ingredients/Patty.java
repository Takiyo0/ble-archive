package us.takiyo.ingredients;

import us.takiyo.extensions.Ingredient;

public class Patty extends Ingredient {
	public Patty() {
		super("patty");
	}
}
