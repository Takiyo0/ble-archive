package us.takiyo.ingredients;

import us.takiyo.extensions.Ingredient;

public class Lettuce extends Ingredient {
	public Lettuce() {
		super("lettuce");
	}
}
