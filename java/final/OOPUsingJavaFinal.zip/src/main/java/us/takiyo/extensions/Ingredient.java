package us.takiyo.extensions;

public class Ingredient {
	public String name;
	public Ingredient(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
}