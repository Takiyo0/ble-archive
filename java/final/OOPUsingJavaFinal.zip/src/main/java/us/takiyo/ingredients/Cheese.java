package us.takiyo.ingredients;

import us.takiyo.extensions.Ingredient;

public class Cheese extends Ingredient{
	public Cheese() {
		super("cheese");
	}
}
